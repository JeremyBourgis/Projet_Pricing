#include <iostream>
#include <cmath>

#include "Binomial.hpp"


using namespace std;

float Szero;
float sigma;
float T;
float R;
float K;


Binomial::Binomial(float Szero, float sigma, float T,float R, float K)
{}

float Binomial::calcBinomial(float Szero  , float sigma, float T,float R, float K)
{
    float u=std::exp(sigma*sqrtf(T));
    float d=std::exp(-sigma*sqrtf(T));

    float SzeroU = Szero*u;
    float SzeroD = Szero*d;
    float Cu=SzeroU-K;
    float Cd=SzeroD-K;
    float p=(std::exp(-R*T)-d)/(u-d);
    float C0=std::exp(-R*T)*(p*Cu+(1-p)*Cd);

    cout  << "On a donc : \n u=";
    cout << u;
    cout  << " \n d=";
    cout << d;
    cout  << "\n S0u=";
    cout << SzeroU;
    cout  << "\n S0d=";
    cout << SzeroD;
    cout  << "\n Cu=";
    cout << Cu;
    cout  << "\n Cd=";
    cout << Cd;
    cout  << "\n C0=";
    cout << C0;

    return C0;
}

