#ifndef Binomial_H
#define Binomial_H

#include <iostream>

using namespace std;

class Binomial
{
public:

    float Szero;
    float sigma;
    float T;
    float R;
    float K;

    // Constructeur
    Binomial(float Szero  , float sigma, float T,float R, float K);

    float calcBinomial(float Szero, float sigma, float T, float R, float K);

};

#endif
