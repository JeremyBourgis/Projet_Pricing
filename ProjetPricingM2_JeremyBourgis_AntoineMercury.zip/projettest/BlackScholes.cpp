#include <iostream>
#include <cmath>

#include "BlackScholes.hpp"

using namespace std;

BlackScholes::BlackScholes(float Szero,float sigma,float T,float R,float K,float div)
{}

float BlackScholes::N(float x)
{
    float result = (erf(x / sqrtf(2)) + 1) / 2;
    return result;
}

float BlackScholes::Nderive(float x)
{
    float result = N(x) * (-x);
    return result;
}

void BlackScholes::greek(float St, float sigma, float T, float R, float K, float d1, float d2)
{
    float deltaCall = N(d1);
    float deltaPut = deltaCall - 1;

    float gamma = Nderive(d1) / (St * sigma * sqrtf(T));

    float vega = St * Nderive(d1) * sqrtf(T);

    float thetaCall = (St * Nderive(d1) * sigma / (2 * sqrtf(T))) + R * K * std::exp(-R * T) * N(d2);
    float thetaPut = (St * Nderive(d1) * sigma / (2 * sqrtf(T))) - R * K * std::exp(-R * T) * N(d2);

    float rhoCall = T * K * std::exp(-R * T) * N(d2);
    float rhoPut = -T * K * std::exp(-R * T) * N(-d2);

    cout << "Les indicateurs grecques: \n DeltaCall=";
    cout << deltaCall;
    cout << " \n DeltaPut=";
    cout << deltaPut;
    cout << "\n Gamma=";
    cout << gamma;
    cout << "\n Vega=";
    cout << vega;
    cout << "\n ThetaCall=";
    cout << thetaCall;
    cout << "\n ThetaPut=";
    cout << thetaPut;
    cout << "\n RhoCall=";
    cout << rhoCall;
    cout << "\n RhoPut=";
    cout << rhoPut;
}

void BlackScholes::propertiesCheck(float C, float P, float St, float K, float R, float T)
{
    char ch;
    cout << "Est-ce une option americaine ou europ�enne (a/e) ?";
    cin >> ch;

    if (C > St || C < St - K * std::exp(-R * T) || C < 0)
    {
        cout << "La propri�te 1 n'est pas respecte";
    }
    else
    {
        cout << "La propri�te 1 est respecte";
    }
    cout << "\n";
    if (ch == 'a')
    {
        if (P > K * std::exp(-R * T) || P < K * std::exp(-R * T) - St || P < 0)
        {
            cout << "La propri�te 2 n'est pas respecte";
        }
        else
        {
            cout << "La propri�te 2 est respecte";
        }
        cout << "\n";
        if (St - K <= C - P && C - P <= St - K * std::exp(-R * T))
        {
            cout << "La formule de parite est  respecte";
        }
        else
        {
            cout << "La formule de parite n'est pas respecte";
        }
    }
    else if (ch == 'e')
    {
        if (P > K || P < K * std::exp(-R * T) - St || P < 0)
        {
            cout << "La propri�te 2 n'est pas respectee";
        }
        else
        {
            cout << "La propri�te 2 est respectee";
        }
        cout << "\n";
        if (C - P == St - K * std::exp(-R * T))
        {
            cout << "La formule de parite est  respectee";
        }
        else
        {
            cout << "La formule de parite n'est pas respectee";
        }
    }
}

void BlackScholes::calcBlackScholes(float St, float sigma, float T, float R, float K)
{
    float d1 = (log(St / K) + (R + ((sigma * sigma) / 2)) * T) / (sigma * sqrtf(T));
    float d2 = d1 - sigma * sqrtf(T);
    // cout << N(d1);

    float call = St * N(d1) - K * std::exp(-R * T) * N(d2);
    float put = K * std::exp(-R * T) * N(-d2) - St * N(-d1);

    cout << "On a donc un call de ";
    cout << call;
    cout << " et un put de ";
    cout << put;
    cout << "\n";

    greek(St, sigma, T, R, K, d1, d2);
    cout << "\n";
    propertiesCheck(call, put, St, K, R, T);
}

void BlackScholes::calcBlackScholesWithDividend(float St, float sigma, float T, float R, float K, float q)
{
    float d1 = (log(St / K) + (R - q + ((sigma * sigma) / 2)) * T) / (sigma * sqrtf(T));
    float d2 = d1 - sigma * sqrtf(T);

    float call = St * N(d1) * std::exp(-q * T) - K * std::exp(-R * T) * N(d2);
    float put = K * std::exp(-R * T) * N(-d2) - St * N(-d1) * std::exp(-q * T);

    cout << "On a donc un call de ";
    cout << call;
    cout << " et un put de ";
    cout << put;
    cout << "\n";

    greek(St, sigma, T, R, K, d1, d2);
    cout << "\n";
    propertiesCheck(call, put, St, K, R, T);
}
