#ifndef BlackScholes_H
#define BlackScholes_H



class BlackScholes
{

public:

    float Szero;
    float sigma;
    float T;
    float R;
    float K;
    float div;

    //Constructeur
    BlackScholes(float Szero, float sigma,float T, float R,float K,float div);

    float N(float x);
    float Nderive(float x);
    void greek(float St, float sigma, float T, float R, float K, float d1, float d2);
    void propertiesCheck(float C, float P, float St, float K, float R, float T);
    void calcBlackScholes(float St, float sigma, float T, float R, float K);
    void calcBlackScholesWithDividend(float St, float sigma, float T, float R, float K, float q);
};

#endif

