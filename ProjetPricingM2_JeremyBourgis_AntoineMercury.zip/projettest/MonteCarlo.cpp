#include <iostream>
#include <random>
#include <stdlib.h>
#include <time.h>
#include <ctime>
#include <list>
#include <algorithm>
#include <chrono>

#include "MonteCarlo.h"


using namespace std;


double S = 0; //prix du sous-jacent
double r = 0; // Taux sans risque
double ecartType = 0; //La volatilit�
//double G; // Variable al�atoier de la loi normale centr�e r�duite
long periodT = 0; // L'�cheance de l'option
double  strikeK = 0; // la prime de l'option
long N; //Nbre de simulations
bool isCall = true;

MonteCarlo::MonteCarlo() : S(100), periodT(1), r(0.2), ecartType(0.25), strikeK(60)
{}

MonteCarlo::MonteCarlo(double S, long periodT, double r, double ecartType, double strikeK) : S(S), periodT(periodT), r(r), ecartType(ecartType), strikeK(strikeK)
{}


double MonteCarlo::genererNbreLoiNormale(){


    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::default_random_engine generator(seed);
    std::normal_distribution<double> distribution(0.0, 1.0);

    return distribution(generator);

}

double MonteCarlo::simuler_une_trajectoire(double S0, long periodT, double r, double ecartType, double NbreLoiNormale){

    double une_simulation = S0*std::exp(r-(ecartType/2)*periodT+ecartType*std::sqrt(periodT)*NbreLoiNormale);
    return une_simulation;
}

list<double> MonteCarlo::simuler_N_trajectoire(int N, double S0,long periodT, double r, double ecartType){

    double une_simulation;
    std::list<double> les_simulations;

    for(int i = 0; i < N; i++){
            double NbreLoiNormale = genererNbreLoiNormale();
            une_simulation = simuler_une_trajectoire(S0, periodT,  r,  ecartType, NbreLoiNormale);
            les_simulations.push_back(une_simulation);
    }
    return les_simulations;
}

double MonteCarlo::calculerPayOff(double prixSim, double strikeK, bool isCall){

    double res;
    if(isCall == true){
        res = std::max(0.0, prixSim - strikeK);
    }else{
        res = std::max(0.0 , strikeK - prixSim);
    }
    return res;

}

std::list <double> MonteCarlo::calculerPayOffs(list<double> les_simulations, double strikeK, bool isCall){

    std::list<double> les_payoffs;
    double payoff = 0;
    for (auto sim: les_simulations) {
        payoff = calculerPayOff(sim,strikeK,isCall);
        les_payoffs.push_back(payoff);
    }

    return les_payoffs;

}

double MonteCarlo::calculerMoyennePayOffs(std::list<double> les_payoffs, double strikeK, bool isCall){

    double moyenne_payoff = 0;

    for (auto payoff: les_payoffs) {
        moyenne_payoff += payoff;
    }

    moyenne_payoff = moyenne_payoff/les_payoffs.size();
    return moyenne_payoff;
}

double MonteCarlo::getPrixCall(long periodT, double r, double ecartType, double strikeK, double espererancePayoffs){

    double prixCall = std::exp(-r*periodT)*espererancePayoffs;
    return prixCall;

}

double MonteCarlo::getPrixPut(long periodT, double r, double ecartType, double strikeK, double espererancePayoffs){

    double prixPut = std::exp(-r*periodT)*espererancePayoffs;
    return prixPut;
}

double MonteCarlo::getMargeInf(double prix, double moyenne_payoff, int N){

    double margeInf = prix-1.96*moyenne_payoff/std::sqrt(N);
    return margeInf;

}

double MonteCarlo::getMargeSup(double prix, double moyenne_payoff, int N){

    double margeSup = prix+1.96*moyenne_payoff/std::sqrt(N);
    return margeSup;

}

void MonteCarlo::pricing_simulation(double S, long periodT, double r, double ecartType, double strikeK, int N){

    bool isCall = true;

    // 1. Simuler des trajectoires al�atoires du sous-jacent
    std::list<double> les_simulations = simuler_N_trajectoire(N, S, periodT, r, ecartType);

    //2. Nous calculons les payoff du call/put C pour toutes les valeurs finales des trajectoires
    std::list<double> les_payoffsCall = calculerPayOffs(les_simulations, strikeK, isCall);
    std::list<double> les_payoffsPut = calculerPayOffs(les_simulations, strikeK, !isCall);

    //3. Nous calculons ensuite l�esp�rance de ces payoff
    double moyenne_payoffsCall = calculerMoyennePayOffs(les_payoffsCall, strikeK, isCall);
    double moyenne_payoffsPut = calculerMoyennePayOffs(les_payoffsPut, strikeK, !isCall);

    //4. Afin d�obtenir l�estimation du prix du call nous actualisons le flux terminal esp�r�, soit
    double prixCall = getPrixCall(periodT, r, ecartType, strikeK, moyenne_payoffsCall);
    cout << "Prix du Call estime = ";
    cout << prixCall;
    cout << "\n";

    double margeSupCall = getMargeSup(prixCall, moyenne_payoffsCall, N);
    double margeInfCall = getMargeInf(prixCall, moyenne_payoffsCall, N);
    cout << "Marge Inferieur = ";
    cout << margeInfCall;
    cout << "\n";

    cout << "Marge Superieur = ";
    cout << margeSupCall;
    cout << "\n";
    cout << "\n";

    double prixPut = getPrixPut(periodT, r, ecartType, strikeK, moyenne_payoffsPut);
    cout << "Prix du Put estime = " ;
    cout << prixPut;
    cout << "\n";

    double margeSupPut = getMargeSup(prixPut, moyenne_payoffsPut, N);
    double margeInfPut = getMargeInf(prixPut, moyenne_payoffsPut, N);
    cout << "Marge Inferieur = ";
    cout << margeInfPut;
    cout << "\n";

    cout << "Marge Superieur = ";
    cout << margeSupPut;
    cout << "\n";
    cout << "\n";



}

