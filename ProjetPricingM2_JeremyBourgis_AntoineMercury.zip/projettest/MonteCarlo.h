#ifndef MonteCarlo_H
#define MonteCarlo_H

#include <iostream>
using namespace std;

class MonteCarlo
{
public:
  // Constructeurs
  MonteCarlo();
  MonteCarlo(double S, long periodT, double r, double ecartType, double strikeK);

  //M�thodes
  double genererNbreLoiNormale();
  double simuler_une_trajectoire(double S0, long periodT, double r, double ecartType, double NbreLoiNormale);
  std::list<double> simuler_N_trajectoire(int N, double S0,long periodT, double r, double ecartType);
  double calculerPayOff(double prixSim, double strikeK, bool isCall);
  std::list <double> calculerPayOffs(list<double> les_simulations, double strikeK, bool isCall);
  double calculerMoyennePayOffs(std::list<double> les_payoffs, double strikeK, bool isCall);
  double getPrixCall(long periodT, double r, double ecartType, double strikeK, double espererancePayoffs);
  double getPrixPut(long periodT, double r, double ecartType, double strikeK, double espererancePayoffs);
  double getMargeInf(double prix, double moyenne_payoff, int N);
  double getMargeSup(double prix, double moyenne_payoff, int N);
  void pricing_simulation(double S, long periodT, double r, double ecartType, double strikeK, int N);

  double S,r,ecartType,strikeK;
  long periodT, N;
  bool isCall;
};

#endif
