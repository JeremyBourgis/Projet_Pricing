#include <iostream>
#include <random>
#include <stdlib.h>
#include <time.h>
#include <ctime>
#include <list>

#include "MonteCarlo.h"
#include "Binomial.hpp"
#include "BlackScholes.hpp"

using namespace std;

int main()
{

    int choix;

    cout << "Bonjour, veuillez choisir votre option de simulations (1= MonteCarlo / 2= Binomial / 3= Black&Scholes)  \n";
    cin >> choix;

     switch (choix) {
        case 1:{

            //declarations des variables
            double S; //prix du sous-jacent
            double strikeK; // la prime de l'option
            long periodT; // L'�cheance de l'option
            double ecartType; //La volatilit�
            double r; // Taux sans risque
            long N; //Nbre de simulations

            //demande des parametres

            cout << "Veuillez entrez le prix du sous-jacent (exemple: 100): ";
            cin >> S;
            cout << "Veuillez entrez la prime de l'option(exemple: 60): ";
            cin >> strikeK;
            cout << "Veuillez entrez l'�cheance de l'option en annee (exemple: 1): ";
            cin >> periodT;
            cout << "Veuillez entrez la volatilite (exemple: 0.25): ";
            cin >> ecartType;
            cout << "Veuillez entrez le taux sans risque (exemple: 0.02): ";
            cin >> r;
            cout << "Veuillez entrez le nombre de simulations souhaite (exemple: 1000): ";
            cin >> N;


            //Execution
            MonteCarlo mc(S,periodT,r,ecartType,strikeK);
            mc.pricing_simulation(mc.S, mc.periodT, mc.r, mc.ecartType, mc.strikeK, N);

        }break;

        case 2:{

            //Declaration des valeurs
            float Szero;
            float sigma;
            float T;
            float R;
            float K;

            //Demande des parametres
            cout << "Donnez la valeur du  parametre S0";
            cin >> Szero;
            cout << "Donnez la valeur du  parametre sigma";
            cin >> sigma;
            cout << "Donnez la valeur du  parametre T";
            cin >> T;
             cout << "Donnez la valeur du  parametre R";
            cin >> R;
             cout << "Donnez la valeur du  parametre K";
            cin >> K;

            Binomial b(Szero,sigma,T,R,K);
            b.calcBinomial(Szero,sigma,T,R,K);

        }break;

        case 3:{

            float Szero;
            float sigma;
            float T;
            float R;
            float K;
            float div;

            cout << "Donnez la valeur du  parametre S0";
            cin >> Szero;
            cout << "Donnez la valeur du  parametre sigma";
            cin >> sigma;
            cout << "Donnez la valeur du  parametre T";
            cin >> T;
            cout << "Donnez la valeur du  parametre R";
            cin >> R;
            cout << "Donnez la valeur du  parametre K";
            cin >> K;
            cout << "Donnez la valeur des  dividendes";
            cin >> div;

            BlackScholes bs(Szero, sigma, T, R, K, div);

            if (div == 0)
            {
                bs.calcBlackScholes(Szero, sigma, T, R, K);
            }
            else
            {
                bs.calcBlackScholesWithDividend(Szero, sigma, T, R, K, div);
            }

        }break;
     }




    return 0;
}



